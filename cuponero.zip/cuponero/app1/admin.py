from django.contrib import admin
from .models import *

# Register your models here.

class CouponAdmin(admin.ModelAdmin):
    list_display = ('code', 'discount', 'valid_from', 'valid_to',)
    search_fields = ('code', 'discount', 'valid_from', 'valid_to',)
    list_filter = ('code', 'discount', 'valid_from', 'valid_to',)

admin.site.register(Coupon,CouponAdmin)
